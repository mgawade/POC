import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Alert } from 'react-native';

import { Header, Right, Icon } from 'native-base'; 
import { Mobstar } from '../tabs/mobstar';
import { Award } from '../tabs/award';
import { Navigation } from 'react-native-navigation';
import { Profile } from '../tabs/profile';
import { Nomination } from '../tabs/nomination';
import { HistoryPage } from '../tabs/history';
import { Nominate } from '../tabs/nominate';

export class Dashboard extends React.Component {
  onRewardsAndRecognizationPress = () => {
Navigation.registerComponent('rnts3.FirstTabScreen', () => Mobstar);
Navigation.registerComponent('rnts3.SecondTabScreen', () => Award);
Navigation.registerComponent('rnts3.ThirdTabScreen', () => Nomination);
Navigation.registerComponent('rnts3.FourthTabScreen', () => HistoryPage);
Navigation.registerComponent('rnts3.FifthTabScreen', () => Profile);
Navigation.registerComponent('rnts3.SixthTabScreen', () => Nominate);

Navigation.startTabBasedApp({
  tabs: [
    {
      label: 'Mobstar',
      screen: 'rnts3.FirstTabScreen', // this is a registered name for a screen
      // icon: require('../img/one.png'),
      // selectedIcon: require('../img/one_selected.png'), // iOS only
      title: 'Mobstar',
    },
    {
      label: 'Award',
      screen: 'rnts3.SecondTabScreen',
      // icon: require('../img/two.png'),
      // selectedIcon: require('../img/two_selected.png'), // iOS only
      title: 'Award',
    },
    {
      label: 'Nomination',
      screen: 'rnts3.ThirdTabScreen',
      // icon: require('../img/two.png'),
      // selectedIcon: require('../img/two_selected.png'), // iOS only
      title: 'Nomination',
    },
    {
      label: 'History',
      screen: 'rnts3.FourthTabScreen',
      // icon: require('../img/two.png'),
      // selectedIcon: require('../img/two_selected.png'), // iOS only
      title: 'History',
    },
    {
      label: 'Profile',
      screen: 'rnts3.FifthTabScreen',
      // icon: require('../img/two.png'),
      // selectedIcon: require('../img/two_selected.png'), // iOS only
      title: 'Profile',
    },
    
  ],
});
  }

  onTimesheetPress = () => {
    Alert.alert("Timesheet")
  };
  onADPPress = () => {
    Alert.alert("ADP")
  };
  onITSubmissionPress = () => {
    Alert.alert("IT Submission")
  };
  onMobCafePress = () => {
    Alert.alert("Mob Cafe")
  };
  
  render() {
    return (
      <View style={styles.container}>
      <Header style={styles.header}><Right>
        
        <Icon name="md-settings" style={{ zIndex: 1 }}/><Text>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</Text>
        <Icon name="ios-log-out" />
       </Right></Header>
        <TouchableOpacity
          style={styles.mobThanksButton}
          onPress={this.onRewardsAndRecognizationPress}
        >
          <Text style={styles.mobThanksButtonText}> Rewards & Recognation </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.mobThanksButton}
          onPress={this.onTimesheetPress}
        >
          <Text style={styles.mobThanksButtonText}> Timesheet </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.mobThanksButton}
          onPress={this.onITSubmissionPress}
        >
          <Text style={styles.mobThanksButtonText}> IT Submission </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.mobThanksButton}
          onPress={this.onADPPress}
        >
          <Text style={styles.mobThanksButtonText}> ADP </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.mobThanksButton}
          onPress={this.onMobCafePress}
        >
          <Text style={styles.mobThanksButtonText}> Mob Cafe </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'gray',
  },
  header: {
    backgroundColor: 'gray',
    marginBottom: '5%',
  },
  dashboard: {
    padding: 10,
    color: 'black',
    marginLeft: '10%',
    marginRight: '10%',
    marginBottom: '10%',
    textAlign: 'center',
    height: 40,
    fontSize: 21,
  },
  mobThanksButtonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 21,
  },
  mobThanksButton: {
    backgroundColor: 'black',
    padding: 10,
    marginLeft: '10%',
    marginRight: '10%',
    marginBottom: '5%',
    height: 60,
    borderWidth: 2,
    borderColor: 'white',
  },
});
