import * as React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  Keyboard,
  ScrollView,
  Alert,
  Image,
} from 'react-native';
import { Navigation } from 'react-native-navigation';
import { Dashboard } from '../Dashboard/Dashboard';

interface DashBoardProps {
 navigator?: any;
}

interface LoginState {
  email: string;
  password: string;
  errorMessage?: string;

}
export class Login extends React.Component<DashBoardProps, LoginState> {
  state: LoginState = {
    email: '',
    password: '',
  };
  handleEmail = text => {
    this.setState({ email: text });
  };
  handlePassword = text => {
    this.setState({ password: text });
  };
  forgotPassword = () => {
    Alert.alert('Verification Link is Sent To Your Mail...');
  }
  login = async () => {
    Keyboard.dismiss();
    const { email: email, password: password } = this.state;

    if (email === '' || password === '') {
      this.setState({ errorMessage: 'username or password is empty' });
    } else if (email.indexOf('@mobiquityinc.com') > 3 && password === '00000') {
      this.setState({
        errorMessage: '',
      });
      Navigation.registerComponent('rnts3.StartTabScreen', () => Dashboard);
      Navigation.startSingleScreenApp({
    screen: {
    screen: 'rnts3.StartTabScreen', // unique ID registered with Navigation.registerScreen
    title: 'Welcome', // title of the screen as appears in the nav bar (optional)
    navigatorStyle: {}, // override the navigator style for the screen, see "Styling the navigator" below (optional)
    navigatorButtons: {} // override the nav buttons for the screen, see "Adding buttons to the navigator" below (optional)
  },
})
    } else {
      this.setState({ errorMessage: 'Username or Password is Incorrect' });
    }

  }
  onSkip=() => {
    Navigation.registerComponent('rnts3.StartTabScreen', () => Dashboard);
    Navigation.startSingleScreenApp({
  screen: {
  screen: 'rnts3.StartTabScreen', // unique ID registered with Navigation.registerScreen
  title: 'Welcome', // title of the screen as appears in the nav bar (optional)
  navigatorStyle: {}, // override the navigator style for the screen, see "Styling the navigator" below (optional)
  navigatorButtons: {} // override the nav buttons for the screen, see "Adding buttons to the navigator" below (optional)
},
})
  }
    

  render() {
    return (
      
      <ScrollView scrollEnabled={false}>
      <View><Text style={styles.skip}
      onPress={this.onSkip}>
      skip</Text></View>
      
        <View style={styles.container}>
        

        <Image
        style={{
          flex: 1,
        }}
        source={{ uri: '/Users/mgawade/Documents/POC/src/images/background.png' }}
      />
        
          <Text style={styles.welcome}>Welcome</Text>
          <Text style={styles.errorMessage}> {this.state.errorMessage}</Text>
          <TextInput
            style={styles.input}
            underlineColorAndroid="transparent"
            placeholder="Username"
            placeholderTextColor="white"
            autoCapitalize="none"
            onSubmitEditing={Keyboard.dismiss}
            
            value={this.state.email}
            onChangeText={this.handleEmail}
          />
          <TextInput
            style={styles.input}
            underlineColorAndroid="transparent"
            placeholder="Enter Password"
            placeholderTextColor="white"
            onSubmitEditing={Keyboard.dismiss}
            secureTextEntry
            value={this.state.password}
            onChangeText={this.handlePassword}
          />
          <TouchableOpacity style={styles.submitButton} onPress={this.login}>
            <Text style={styles.submitButtonText}> Login </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={this.forgotPassword}>
            <Text> Forgot Password ? </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
  },
  
  errorMessage: {
    fontSize: 15,
    textAlign: 'center',
    color: 'red',
    
  },
  skip: {
    fontSize: 10,
    textAlign: 'right',
    color: 'black',
  },
  welcome: {
    fontSize: 30,
    textAlign: 'center',
    color: 'black',
  },
  logo: {
    width: 1136,
    height: 640,
  },
  input: {
    backgroundColor: 'black',
    padding: 10,
    marginLeft: '10%',
    marginRight: '10%',
    marginBottom: '5%',
    height: 33,
    width: 155,
    color: 'white',
    borderWidth: 1,
    borderColor: 'white',
  },
  submitButton: {
    backgroundColor: '#b5b3b3',
    padding: 10,
    height: 40,
    width: 180,
    borderWidth: 1,
    borderColor: 'white',
    marginLeft: '10%',
    marginRight: '10%',
    marginBottom: '10%',
  },
  submitButtonText: {
    color: 'white',
    textAlign: 'center',
  },
  backgroundImage: {
    flex: 1,
    width: null,
    height: null,
    resizeMode: 'cover',
  },
});
