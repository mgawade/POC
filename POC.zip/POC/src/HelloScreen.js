// JavaScript screen component wrapper for hot reloading compatibility
// Without this (using `Hello` directly when registering) hot reloading
// does not work.

import React from 'react';
import { Login } from 'src/Login';

class HelloScreen extends React.Component {
  render() {
    return <Login />;
  }
}

export default HelloScreen;
