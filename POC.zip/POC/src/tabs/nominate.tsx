import * as React from 'react';
import {
  StyleSheet,
  Alert,
  TextInput,
  TouchableOpacity,
  Text,
  View,
  ListView,
  ActivityIndicator,
} from 'react-native';
import { SearchBar } from 'react-native-elements'
import { Dropdown } from 'react-native-material-dropdown';

interface ChatState {
  message: string;
  wowCard: string;
  errorMessage?: string;
  history: String[];
  isLoading: boolean;
  text: string;
  arrayHolder: any[];
  dataSource: any;
  isListLoading: boolean;
  selectedEmail?: string,
}
export class Nominate extends React.Component<ChatState> {
  state: ChatState = {
    message: '',
    wowCard: '',
    errorMessage: '',
    history: [],
    isLoading: true,
    text: '',
    arrayHolder: [],
    dataSource: '',
    isListLoading: false,
    selectedEmail: '',
  };
  handleMessage = text => {
    this.setState({ message: text });
  };
  handleWowcard = text => {
    this.setState({ wowCard: text });
  };
  onSend = () => {
    const message = this.state.message;
    if (message === '') {
      Alert.alert('Message Cannot be Empty');
    } else {
      Alert.alert(
        'Are You Sure ?',
        'Are You sure, want to submit this nomination ?',
        [
          {
            text: 'Yes , Please',
            onPress: () =>
              Alert.alert(
                'Your WOW Card : ' +
                  `${this.state.wowCard}` +
                  ' And Message : ' +
                  `${this.state.message}` +
                  ' Sent Successfully to ',  +
                  `${this.state.selectedEmail}` +''
              ),
          },
          { text: 'No , Thanks', onPress: () => 'Cancel Pressed' },
        ],
      );
    }
  };
  changeText = () => {
    alert('ok');
  };
  onSave = () => {
    const message = this.state.message;
    if (message === '') {
      alert('Message Cannot be Empty');
    } else {
      Alert.alert(
        'Your WOW Card : "' +
                  `${this.state.wowCard}` + '" And  Message "' + 
                  `${this.state.message}` + '" Saved Successfully',
      );
    }
  };
  componentDidMount() {
    return fetch(
      '/Users/mgawade/Documents/POC/src/data.json',
    )
      .then(response => response.json())
      .then(responseJson => {
        
        const ds = new ListView.DataSource({
          rowHasChanged: (r1, r2) => r1 !== r2,
        });
        this.setState(
          {
            isLoading: false,
            dataSource: ds.cloneWithRows(responseJson),
            arrayHolder : responseJson,
            
          },
        );
      })
      .catch(error => {
        console.error(error);
      });
  }

  getListViewItem(value) {
    this.setState({
      selectedEmail : value,
    });
    this.state.isListLoading= false;
  }
 
  searchFilterFunction = text => {
    if (text != null) {
      const newData = this.state.arrayHolder.filter(item => {
        const itemData = item.email.toLowerCase();
        const textData = text.toLowerCase();
        return itemData.indexOf(textData) > -1;
      });
      this.setState({
      
        dataSource: this.state.dataSource.cloneWithRows(newData),
        isListLoading : true,
      
        selectedEmail: this.state.dataSource.cloneWithRows(newData)[0],
      });
    }else {
      this.setState({
        dataSource: [],
        isListLoading : true,
      });
    }
  };
  render() {
    if (this.state.isLoading) {
      return (
        <View style={{ flex: 1, paddingTop: 20 }}>
          <ActivityIndicator />
        </View>
      );
    }
    const data = [
      {
        value: 'Thank You',
      },
      {
        value: 'Thanks For Being There',
      },
      {
        value: 'Pat On Back',
      },
    ];
    return (
      
      <View style={{ padding: 10 }}>
      
      <SearchBar
      round
      lightTheme
      onChangeText={text => this.searchFilterFunction(text)}
      value={this.state.selectedEmail}
      autoCapitalize={'none'} 
        placeholder='search employee name'
        placeholderTextColor='gray' />
       {this.state.isListLoading &&  <ListView
            dataSource={this.state.dataSource}
            
            // tslint:disable-next-line:jsx-no-lambda
            renderRow={rowData => (
              <Text
                style={styles.rowViewContainer}
                onPress={() => this.getListViewItem(rowData.email)}
                
              >
                {rowData.email}
              </Text>
            )}
            // tslint:disable-next-line:jsx-boolean-value
            enableEmptySections={true}
            style={{ marginTop: 10 }}

          />}  
        <Dropdown
          style={styles.list}
          placeholder={'AWARD CATEGORY'}
          data={data}
          value={this.state.wowCard}
          onChangeText={this.handleWowcard}
        />

        <TextInput
          style={styles.input}
          // tslint:disable-next-line:jsx-boolean-value
          multiline={true}
          numberOfLines={4}
          placeholder={'Type a message ...'}
          autoCorrect={false}
          spellCheck={false}
          autoCapitalize="none"
          value={this.state.message}
          onChangeText={this.handleMessage}
        />
        <Text>
          <TouchableOpacity style={styles.saveButton} onPress={this.onSave}>
            <Text style={styles.saveButtonText}> SAVE </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.sendButton} onPress={this.onSend}>
            <Text style={styles.sendButtonText}>SUBMIT</Text>
          </TouchableOpacity>
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({ 
  list: {
    backgroundColor: '#d6d8db',
    height: 28,
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 25,
    borderWidth: 0.5,
    borderColor: '#d6d8db',
    textAlign: 'left',
  },
  input: {
    marginTop: 5,
    height: 270,
    borderColor: '#ccc9c9',
    borderWidth: 1,
    textAlign: 'auto',
    backgroundColor: 'white',
    marginBottom: 30,
  },
  sendButton: {
    backgroundColor: 'white',
    height: 35,
    width: 160,
    borderRadius: 30,
    borderWidth: 1,
    borderColor: 'gray',
    marginLeft: '20%',
  },
  saveButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'gray',
    height: 35,
    width: 160,   
    borderRadius: 30,
  },
  saveButtonText: {
    color: 'black',
    textAlign: 'center',
    fontWeight: 'bold',
    marginTop: 11,
    fontSize: 12,
  },
  sendButtonText: {
    color: 'black',
    textAlign: 'center',
    fontWeight: 'bold',
    marginTop: 11,
    fontSize: 12,
  },
  rowViewContainer: {
    fontSize: 17,
    padding: 10,
  },

  
});
