import * as React from 'react';
import {
  Container,
  Header,
  Content,
  Icon,
  Picker,
  Form,
  View,
} from 'native-base';
import { ViewStyle } from 'react-native';
interface HistoryState {
  selectedMonth: any;
  selectedYear: any;
}
export class HistoryPage extends React.Component<HistoryState> {
  myFunction() {
    var month = new Array();
    month[0] = 'January';
    month[1] = 'February';
    month[2] = 'March';
    month[3] = 'April';
    month[4] = 'May';
    month[5] = 'June';
    month[6] = 'July';
    month[7] = 'August';
    month[8] = 'September';
    month[9] = 'October';
    month[10] = 'November';
    month[11] = 'December';

    var d = new Date();
    var n = month[d.getMonth()];
    return n;
  }

  state: HistoryState = {
    selectedMonth: '',
    selectedYear: new Date().getFullYear(),
  };
  onValueChange(value) {
    this.setState({
      selectedMonth: value,
    });
    // alert(value);
  }
  onYearChange(value) {
    this.setState({
      selectedYear: value,
    });
  }

  render() {
    return (
      <Container>
        <Content>
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <Picker
              mode="dropdown"
              placeholder={this.state.selectedYear}
              iosIcon={<Icon name="ios-arrow-down-outline" />}
              textStyle={{ color: 'black' }}
              itemTextStyle={{ color: '#788ad2' }}
              style={{
                width: 170,
                height: 30,
                borderWidth: 1,
                borderColor: '#e3e3e5',
                borderRadius: 30,
                backgroundColor: '#d8d8d8',
                marginTop: 20,
                marginRight: 10,
                marginLeft: 5,
              }}
              selectedValue={this.state.selectedYear}
              onValueChange={this.onYearChange.bind(this)}
            >
              <Picker.Item label="2018" value="2018" />
              <Picker.Item label="2017" value="2017" />
              <Picker.Item label="2016" value="2016" />
              <Picker.Item label="2015" value="2015" />
            </Picker>

            <Picker
              mode="dropdown"
              placeholder={this.myFunction()}
              iosIcon={<Icon name="ios-arrow-down-outline" />}
              textStyle={{ color: 'black' }}
              itemTextStyle={{ color: '#788ad2' }}
              style={{
                width: 170,
                height: 30,
                borderWidth: 1,
                borderColor: '#e3e3e5',
                fontWeight: '900',
                borderRadius: 30,
                backgroundColor: '#d8d8d8',
                marginTop: 20,
                marginLeft: 15,
              }}
              selectedValue={this.state.selectedMonth}
              onValueChange={this.onValueChange.bind(this)}
            >
              <Picker.Item label="January" value="January" />
              <Picker.Item label="February" value="February" />
              <Picker.Item label="March" value="March" />
              <Picker.Item label="April" value="April" />
              <Picker.Item label="May" value="May" />
              <Picker.Item label="June" value="June" />
              <Picker.Item label="July" value="July" />
              <Picker.Item label="August" value="August" />
              <Picker.Item label="September" value="September" />
              <Picker.Item label="October" value="October" />
              <Picker.Item label="November" value="November" />
              <Picker.Item label="December" value="December" />
            </Picker>
          </View>
        </Content>
      </Container>
    );
  }
}
