import * as React from 'react';
import { StyleSheet, View, FlatList } from 'react-native';
import {
  Input,
  Thumbnail,
  Text,
  Button,
  Icon,
} from 'native-base';
export interface CardViewState {
  totalLikes: number;
  totalComments: number;
  defaultCommetText: string;
  isLoading: boolean;
  dataSource: String[];
}
export interface CardViewProps {
  totalLikes: number;
  totalComments: number;
  defaultCommetText: string;
  isLoading: boolean;
  dataSource: String[];
  navigator?: any;
}

export class Nomination extends React.Component<CardViewProps, CardViewState> {
  props: CardViewProps = {
    totalLikes: null,
    totalComments: null,
    defaultCommetText: 'Type a message',
    isLoading: false,
    dataSource: [],
  };
  state: CardViewState = {
    totalLikes: this.props.totalLikes,
    totalComments: this.props.totalComments,
    defaultCommetText: 'Type a message',
    isLoading: this.props.isLoading,
    dataSource: this.props.dataSource,
  };
  componentDidMount() {
    return fetch('/Users/mgawade/Documents/POC/src/MobStarData.json')
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: false,
          dataSource: responseJson,
        });
      })
      .catch(error => {
        console.error(error);
      });
  }
  onPressLike = () => {
    this.setState({
      totalLikes: this.state.totalLikes + 1,
    });
  };
  onComment = () => {
    this.setState({
      totalComments: this.state.totalComments + 1,
      defaultCommetText: 'Type a message',
    });
  };

  onNominate = () => {
    
    this.props.navigator.push({
      screen: 'rnts3.SixthTabScreen', // unique ID registered with Navigation.registerScreen
      title: undefined, // navigation bar title of the pushed screen (optional)
      subtitle: undefined, // navigation bar subtitle of the pushed screen (optional)
      passProps: {}, // Object that will be passed as props to the pushed screen (optional)
      animated: true,
      animationType: 'fade',
      backButtonTitle: undefined, // override the back button title (optional)
      backButtonHidden: false, // hide the back button altogether (optional)
      navigatorStyle: {}, // override the navigator style for the pushed screen (optional)
      navigatorButtons: {}, // override the nav buttons for the pushed screen (optional)
      // enable peek and pop - commited screen will have `isPreview` prop set as true.
      previewView: undefined, // react ref or node id (optional)
      previewHeight: undefined, // set preview height, defaults to full height (optional)
      previewCommit: true, // commit to push preview controller to the navigation stack (optional)
      previewActions: [
        {
          id: '', // action id (required)
          title: '', // action title (required)
          style: undefined, // 'selected' or 'destructive' (optional)
          actions: [], // list of sub-actions
        },
      ],
    });
  };

  render() {
    return (
      <View style={styles.container}>
        <Button
          rounded
          success
          style={styles.nominate}
          onPress={this.onNominate}
        >
          <Text style={styles.nominateButtonText}>NOMINATE BEST EMPLOYEE</Text>
        </Button>
        <Text>My Nominations</Text>
       <View>
       <FlatList
         data={this.state.dataSource}
         // tslint:disable-next-line:jsx-no-lambda
         renderItem={data => (
           <View style={styles.cardViewStyle}>
             <View style={styles.cardViewHeaderStyle}>
               <Thumbnail
                 source={{
                   uri:
                     // tslint:disable-next-line:max-line-length
                     '/Users/mgawade/Documents/POC/src/images/user.png',
                 }}
                 style={styles.cardViewHeaderImageStyle}
                 circular
               />

               <View style={styles.cardViewHeaderTextStyle}>
                 <View>
                   <Text style={styles.cardViewHeaderName}>
                     Nominated To | {data.item.Name}
                   </Text>
                   <Text style={styles.cardViewHeaderDate}>
                     {data.item.nominatedFor} - {data.item.date}
                   </Text>
                 </View>
               </View>
             </View>
             <View style={styles.descriptionViewStyle}>
               <Text style={styles.descriptionViewTextStyle}>
                 {data.item.description}
               </Text>
             </View>
             <View style={styles.likeCommentViewStyle}>
               <View
                 style={{
                   flexDirection: 'row',
                   justifyContent: 'space-between',
                 }}
               >
                 <Button transparent small>
                   <Icon
                     name="md-thumbs-up"
                     style={styles.likeCommentBarStyle}
                   />
                 </Button>

                 <Text style={styles.totalLikesStyles}>
                   {data.item.totalLikes}
                 </Text>
                 <Text style={styles.totalCommentStyles}>
                   {this.state.totalComments} Comments
                   {data.item.totalComments}
                 </Text>
               </View>
             </View>
             <View style={styles.cardViewFooterStyles}>
               <Button transparent>
                 <Icon name="md-thumbs-up" onPress={this.onPressLike} />
               </Button>
               <Input
                 placeholder={this.state.defaultCommetText}
                 onEndEditing={this.onComment}
                 // tslint:disable-next-line:max-line-length
                 spellCheck
                 autoCapitalize={'sentences'}
                 style={styles.cardViewCommentBoxStyle}
               />
             </View>
           </View>
         )}
       />
     </View>
     </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nominate: {
    backgroundColor: '#d1d1d1',
    alignItems: 'center',
    marginLeft: '8%',
    marginRight: '15%',
    marginTop: '23%',
    marginBottom: '3%',
    paddingLeft: 40,
    height: 30,
    width: 320,
  },
  nominateButtonText: {
    color: 'black',
    textAlign: 'center',
    justifyContent: 'center',
  },
  cardViewStyle: {
    shadowColor: '#a1a2a3',
    borderWidth: 1,
    borderColor: '#c5c7c9',
    marginLeft: 10,
    marginRight: 10,
    marginTop: 10,
  },
  cardViewHeaderStyle: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#f7f7f7',
    height: 45,
  },
  cardViewHeaderImageStyle: {
    width: 45,
    height: 49,
    marginTop: 10,
    marginLeft: 10,
    flex: 0.3,
  },
  cardViewHeaderTextStyle: {
    flexDirection: 'row',
    marginTop: 10,
    marginLeft: 10,
  },
  cardViewHeaderName: {
    color: '#4f4e4e',
    fontSize: 12,
  },
  cardViewHeaderDate: {
    color: '#000000',
    fontWeight: 'bold',
    fontSize: 12,
  },
  descriptionViewStyle: {
    marginLeft: 10,
    marginRight: 10,
  },
  descriptionViewTextStyle: {
    textAlignVertical: 'auto',
    textAlign: 'justify',
    color: '#4f4e4e',
    fontSize: 12,
  },
  likeCommentViewStyle: {
    flexDirection: 'row',
  },
  likeCommentBarStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  totalLikesStyles: {
    marginTop: 6,
    fontSize: 12,
  },
  totalCommentStyles: {
    marginTop: 6,
    marginLeft: 190,
    fontSize: 12,
  },
  cardViewFooterStyles: {
    flexDirection: 'row',
    flexGrow: 3,
    width: 345,
  },
  cardViewCommentBoxStyle: {
    height: 40,
    borderWidth: 1,
    borderColor: '#e3e3e5',
    borderRadius: 20,
    flexWrap: 'wrap',
  },
});
