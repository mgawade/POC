import * as React from 'react';
import { StyleSheet, View, Text, FlatList } from 'react-native';
import { Icon, Thumbnail, Button, Input } from 'native-base';
export interface CardViewState {
  totalLikes: number;
  totalComments: number;
  defaultCommetText: string;
  isLoading: boolean;
  dataSource: String[];
}
export interface CardViewProps {
  totalLikes: number;
  totalComments: number;
  defaultCommetText: string;
  isLoading: boolean;
  dataSource: String[];
}
export class Award extends React.Component<CardViewState, CardViewProps> {
  props: CardViewProps = {
    totalLikes: null,
    totalComments: null,
    defaultCommetText: 'Type a message',
    isLoading: false,
    dataSource: [],
  };
  state: CardViewState = {
    totalLikes: this.props.totalLikes,
    totalComments: this.props.totalComments,
    defaultCommetText: 'Type a message',
    isLoading: this.props.isLoading,
    dataSource: this.props.dataSource,
  };
  componentDidMount() {
    // tslint:disable-next-line:max-line-length
    return fetch(
      // tslint:disable-next-line:max-line-length
      '/Users/mgawade/Documents/POC/src/MobStarData.json',
    )
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: false,
          dataSource: responseJson,
        });
      })
      .catch(error => {
        console.error(error);
      });
  }
  onPressLike = (data, index) => () => {
    const myData: any = this.state.dataSource;
    for (let i = 0; i < this.state.dataSource.length; i = i + 1) {
      if (i === index) {
        myData[i].totalLikes = +myData[i].totalLikes + 1;
      }
    }
    this.setState({
      dataSource: myData,
    });
  };
  onComment = index => () => {
    const myData: any = this.state.dataSource;
    for (let i = 0; i < this.state.dataSource.length; i = i + 1) {
      if (i === index) {
        myData[i].totalComments = +myData[i].totalComments + 1;
      }
    }
    this.setState({
      dataSource: myData,
    });
  };
  render() {
    return (
      <View>
        {this.state.dataSource.map((data: any, index) => (
          <View style={styles.cardViewStyle}>
            <View style={styles.cardViewHeaderStyle}>
              <Thumbnail
                source={{
                  uri:
                    // tslint:disable-next-line:max-line-length
                    '/Users/mgawade/Documents/POC/src/images/user.png',
                }}
                style={styles.cardViewHeaderImageStyle}
                circular
              />

              <View style={styles.cardViewHeaderTextStyle}>
                <View>
                  <Text style={styles.cardViewHeaderName}>
                    {data.Name} | {data.Designation}
                  </Text>
                  <Text style={styles.cardViewHeaderDate}>
                    {data.nominatedFor} - {data.date}
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.descriptionViewStyle}>
              <Text style={styles.descriptionViewTextStyle}>
                {data.description}
              </Text>
            </View>
            <View style={styles.likeCommentViewStyle}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <Button transparent small>
                  <Icon
                    name="md-thumbs-up"
                    style={styles.likeCommentBarStyle}
                  />
                </Button>

                <Text style={styles.totalLikesStyles}>{data.totalLikes}</Text>
                <Text style={styles.totalCommentStyles}>
                  {data.totalComments} Comments
                </Text>
              </View>
            </View>
            <View style={styles.cardViewFooterStyles}>
              <Button transparent>
                <Icon
                  name="md-thumbs-up"
                  onPress={this.onPressLike(data, index)}
                />
              </Button>

              <Input
                placeholder={this.state.defaultCommetText}
                onEndEditing={this.onComment(index)}
                // tslint:disable-next-line:max-line-length
                spellCheck
                autoCapitalize={'sentences'}
                style={styles.cardViewCommentBoxStyle}
              />
            </View>
          </View>
        ))}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  cardViewStyle: {
    shadowColor: '#a1a2a3',
    borderWidth: 1,
    borderColor: '#c5c7c9',
    marginLeft: 10,
    marginRight: 10,
    marginTop: 10,
  },
  cardViewHeaderStyle: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#f7f7f7',
    height: 65,
  },
  cardViewHeaderImageStyle: {
    width: 10,
    height: 33,
    marginTop: 10,
    marginLeft: 10,
    flex: 0.3,
  },
  cardViewHeaderTextStyle: {
    flexDirection: 'row',
    marginTop: 10,
    marginLeft: 10,
  },
  cardViewHeaderName: {
    color: '#4f4e4e',
    fontSize: 12,
  },
  cardViewHeaderDate: {
    color: '#000000',
    fontWeight: 'bold',
    fontSize: 12,
  },
  descriptionViewStyle: {
    marginLeft: 10,
    marginRight: 10,
  },
  descriptionViewTextStyle: {
    textAlignVertical: 'auto',
    textAlign: 'justify',
    color: '#4f4e4e',
    fontSize: 12,
  },
  likeCommentViewStyle: {
    flexDirection: 'row',
  },
  likeCommentBarStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  totalLikesStyles: {
    marginTop: 6,
    fontSize: 12,
  },
  totalCommentStyles: {
    marginTop: 6,
    marginLeft: 190,
    fontSize: 12,
  },
  cardViewFooterStyles: {
    flexDirection: 'row',
    flexGrow: 3,
    width: 345,
  },
  cardViewCommentBoxStyle: {
    height: 40,
    borderWidth: 1,
    borderColor: '#e3e3e5',
    borderRadius: 20,
    flexWrap: 'wrap',
  },
});
