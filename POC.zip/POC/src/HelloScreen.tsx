// JavaScript screen component wrapper for hot reloading compatibility
// Without this (using `Hello` directly when registering) hot reloading
// does not work.

import * as React from 'react';
import { Hello } from './Hello';

class HelloScreen extends React.Component {
  render() {
    return <Hello />;
  }
}

// tslint:disable-next-line:no-default-export
export default HelloScreen;
